const express = require("express");
const app = require("./app");
const bodyParser = require("body-parser");
const PORT = 4000;

 app.use(express.static(__dirname + "/public"));
 app.use("view engine", "ejs");
 app.use("views", "./views");

 app.get("/", (req,res) =>{
 res.send("Welcome");
});
app.listen(PORT, () => console.log(`Server started on ${PORT}`));
