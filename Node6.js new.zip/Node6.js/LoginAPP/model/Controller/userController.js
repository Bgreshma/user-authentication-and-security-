const express = require("express");
const User = require("../model/user");
const { model } = require("mongoose");
const router = express.Router();

 router.get("/signup", (req,res) =>{
    res.render("signup, ejs");
 });
 
  model.exports = router;

