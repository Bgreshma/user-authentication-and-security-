const express = require("express");
const app = express();
const db = require("./db");
const UserController = require("./model/Controller/userController");

app.use("/user", UserController);

module.exports= app;


